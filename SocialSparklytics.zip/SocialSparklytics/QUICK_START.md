# Quick Start Guide

## Get Started in 2 Minutes

### Step 1: Add Your OpenAI API Key

1. Click on the **Secrets** tab (🔒 icon) in Replit
2. Add a new secret:
   - **Key:** `OPENAI_API_KEY`
   - **Value:** Your OpenAI API key (starts with `sk-...`)

Don't have an API key? Get one at https://platform.openai.com/api-keys

### Step 2: Test the API

The server is already running! Test it with these commands:

```bash
# Health check
curl https://YOUR-REPLIT-URL/api/v1/health

# Create a task
curl -X POST "https://YOUR-REPLIT-URL/api/v1/tasks" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Create Instagram marketing strategy",
    "description": "Design a 30-day Instagram marketing plan for a coffee shop"
  }'

# Save the task ID from the response, then check status:
curl https://YOUR-REPLIT-URL/api/v1/tasks/TASK_ID

# Once status is "completed", get the result:
curl https://YOUR-REPLIT-URL/api/v1/tasks/TASK_ID/result
```

### Step 3: Explore the Interactive Docs

Visit these URLs in your browser:
- **Swagger UI:** `https://YOUR-REPLIT-URL/docs`
- **ReDoc:** `https://YOUR-REPLIT-URL/redoc`

Both provide interactive testing interfaces where you can:
- Try all API endpoints
- See request/response examples
- Test without writing curl commands

## What Happens When You Create a Task?

1. **Task Created** - Your task is saved to PostgreSQL with a unique ID
2. **Added to Queue** - Task is added to priority queue
3. **LLM Planning** (2-5 seconds) - OpenAI GPT-4o-mini breaks it down into 3-10 steps
4. **Execution** (5-30 seconds) - Worker executes each step sequentially
5. **Result Saved** - Aggregated results stored and ready for retrieval

## Example Workflow

```bash
# 1. Create task
RESPONSE=$(curl -s -X POST "https://YOUR-REPLIT-URL/api/v1/tasks" \
  -H "Content-Type: application/json" \
  -d '{"title": "Generate social media content", "description": "Create 10 Instagram post ideas for a fitness brand"}')

# 2. Extract task ID (requires jq - install with: brew install jq)
TASK_ID=$(echo $RESPONSE | jq -r '.id')
echo "Task created: $TASK_ID"

# 3. Wait and check status
sleep 10
curl -s "https://YOUR-REPLIT-URL/api/v1/tasks/$TASK_ID" | jq '.status'

# 4. Get final result
curl -s "https://YOUR-REPLIT-URL/api/v1/tasks/$TASK_ID/result" | jq '.'
```

## Task Examples

### Example 1: Marketing Strategy
```json
{
  "title": "Social media campaign for product launch",
  "description": "Create a complete 2-week social media campaign for launching a new fitness app, including post schedule, content ideas, and engagement tactics",
  "priority": 8
}
```

### Example 2: Content Creation
```json
{
  "title": "Blog content ideas",
  "description": "Generate 20 blog post ideas for a sustainable fashion brand targeting Gen Z, with SEO keywords and content outlines",
  "priority": 5
}
```

### Example 3: Business Planning
```json
{
  "title": "Market research plan",
  "description": "Design a comprehensive market research plan for entering the plant-based food market in Europe",
  "priority": 7
}
```

## Monitoring

### Check Server Logs
View the workflow console in Replit to see:
- Task creation events
- LLM planning progress
- Worker execution logs
- Errors and warnings

### Check Task Logs
Every task includes detailed logs:
```bash
curl https://YOUR-REPLIT-URL/api/v1/tasks/TASK_ID | jq '.logs'
```

## Troubleshooting

### "Database: unhealthy" in health check
This is expected initially. The database becomes healthy after first task creation.

### Tasks stuck in "planning" status
- Check if OPENAI_API_KEY is set correctly
- View server logs for OpenAI API errors
- System will use fallback planning if OpenAI fails

### Tasks stuck in "pending" status
- Worker might be busy with another task
- Wait 5-10 seconds and check again
- Check server logs for worker errors

### "Task is not completed yet" error
- Task is still processing
- Check `/tasks/TASK_ID` for current status
- Only completed tasks can be retrieved via `/tasks/TASK_ID/result`

## Next Steps

1. **Read Full Documentation:**
   - [README.md](README.md) - Complete overview
   - [TESTING.md](TESTING.md) - Comprehensive API examples
   - [ARCHITECTURE.md](ARCHITECTURE.md) - Technical architecture

2. **Understand Limitations:**
   - [PRODUCTION_READINESS.md](PRODUCTION_READINESS.md) - Production requirements

3. **Deploy to Production:**
   - Follow migration guide in ARCHITECTURE.md
   - Implement critical fixes from PRODUCTION_READINESS.md
   - Set up monitoring and alerts

## Support

- **API Docs:** `/docs` and `/redoc` endpoints
- **Project Docs:** See README.md, TESTING.md, ARCHITECTURE.md
- **Issues:** Check PRODUCTION_READINESS.md for known issues

---

**You're ready to test the AI Execution Hub!** 🚀
