from sqlalchemy.orm import Session, joinedload
from typing import List, Optional
from app.models.task import Task, TaskStep, ExecutionLog, TaskResult, TaskStatus
from app.core.logging import get_logger

logger = get_logger(__name__)


class TaskRepository:
    def __init__(self, db: Session):
        self.db = db
    
    def create_task(self, task: Task) -> Task:
        self.db.add(task)
        self.db.commit()
        self.db.refresh(task)
        logger.info(f"Created task: {task.id}")
        return task
    
    def get_task(self, task_id: str) -> Optional[Task]:
        return self.db.query(Task).filter(Task.id == task_id).first()
    
    def get_task_with_details(self, task_id: str) -> Optional[Task]:
        return self.db.query(Task).options(
            joinedload(Task.steps),
            joinedload(Task.logs),
            joinedload(Task.result)
        ).filter(Task.id == task_id).first()
    
    def get_tasks(self, status: Optional[TaskStatus] = None, limit: int = 100) -> List[Task]:
        query = self.db.query(Task)
        if status:
            query = query.filter(Task.status == status)
        return query.order_by(Task.created_at.desc()).limit(limit).all()
    
    def update_task(self, task: Task) -> Task:
        self.db.commit()
        self.db.refresh(task)
        return task
    
    def delete_task(self, task_id: str) -> bool:
        task = self.get_task(task_id)
        if task:
            self.db.delete(task)
            self.db.commit()
            logger.info(f"Deleted task: {task_id}")
            return True
        return False
    
    def create_step(self, step: TaskStep) -> TaskStep:
        self.db.add(step)
        self.db.commit()
        self.db.refresh(step)
        return step
    
    def create_log(self, log: ExecutionLog) -> ExecutionLog:
        self.db.add(log)
        self.db.commit()
        self.db.refresh(log)
        return log
    
    def create_result(self, result: TaskResult) -> TaskResult:
        self.db.add(result)
        self.db.commit()
        self.db.refresh(result)
        return result
    
    def get_pending_tasks(self) -> List[Task]:
        return self.db.query(Task).filter(
            Task.status == TaskStatus.PENDING
        ).order_by(Task.priority.desc(), Task.created_at).all()
