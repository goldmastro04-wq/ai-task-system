from abc import ABC, abstractmethod
from typing import Optional, Any, Dict


class QueueInterface(ABC):
    """Abstract interface for queue systems (database, Redis, RabbitMQ)"""
    
    @abstractmethod
    async def enqueue(self, queue_name: str, task_data: Dict[str, Any], priority: int = 0) -> str:
        """Add a task to the queue"""
        pass
    
    @abstractmethod
    async def dequeue(self, queue_name: str) -> Optional[Dict[str, Any]]:
        """Get next task from the queue"""
        pass
    
    @abstractmethod
    async def get_queue_size(self, queue_name: str) -> int:
        """Get number of items in queue"""
        pass
    
    @abstractmethod
    async def clear_queue(self, queue_name: str) -> int:
        """Clear all items from queue"""
        pass
