from typing import Optional, Any, Dict
from sqlalchemy import Column, String, Integer, DateTime, JSON, Text
from sqlalchemy.orm import Session
from datetime import datetime
from app.core.database import Base
from app.queue.base import QueueInterface
from app.core.logging import get_logger
import json

logger = get_logger(__name__)


class QueueItem(Base):
    __tablename__ = "queue_items"
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    queue_name = Column(String(100), nullable=False, index=True)
    task_id = Column(String, nullable=False, index=True)
    task_data = Column(JSON, nullable=False)
    priority = Column(Integer, default=0, index=True)
    status = Column(String(20), default="pending", index=True)  # pending, processing, completed
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    processed_at = Column(DateTime, nullable=True)
    error = Column(Text, nullable=True)


class DatabaseQueue(QueueInterface):
    """Database-backed queue (portable, can be replaced with Redis later)"""
    
    def __init__(self, db_session: Session):
        self.db = db_session
    
    async def enqueue(self, queue_name: str, task_data: Dict[str, Any], priority: int = 0) -> str:
        task_id = task_data.get("task_id", "unknown")
        
        queue_item = QueueItem(
            queue_name=queue_name,
            task_id=task_id,
            task_data=task_data,
            priority=priority
        )
        
        self.db.add(queue_item)
        self.db.commit()
        self.db.refresh(queue_item)
        
        logger.info(f"Enqueued task {task_id} to queue {queue_name}")
        return str(queue_item.id)
    
    async def dequeue(self, queue_name: str) -> Optional[Dict[str, Any]]:
        queue_item = self.db.query(QueueItem).filter(
            QueueItem.queue_name == queue_name,
            QueueItem.status == "pending"
        ).order_by(
            QueueItem.priority.desc(),
            QueueItem.created_at
        ).first()
        
        if queue_item:
            queue_item.status = "processing"
            queue_item.processed_at = datetime.utcnow()
            self.db.commit()
            
            logger.info(f"Dequeued task {queue_item.task_id} from queue {queue_name}")
            return queue_item.task_data
        
        return None
    
    async def get_queue_size(self, queue_name: str) -> int:
        count = self.db.query(QueueItem).filter(
            QueueItem.queue_name == queue_name,
            QueueItem.status == "pending"
        ).count()
        return count
    
    async def clear_queue(self, queue_name: str) -> int:
        deleted = self.db.query(QueueItem).filter(
            QueueItem.queue_name == queue_name
        ).delete()
        self.db.commit()
        logger.info(f"Cleared {deleted} items from queue {queue_name}")
        return deleted
    
    def mark_completed(self, task_id: str):
        """Mark queue item as completed"""
        self.db.query(QueueItem).filter(
            QueueItem.task_id == task_id,
            QueueItem.status == "processing"
        ).update({"status": "completed"})
        self.db.commit()
    
    def mark_failed(self, task_id: str, error: str):
        """Mark queue item as failed"""
        self.db.query(QueueItem).filter(
            QueueItem.task_id == task_id,
            QueueItem.status == "processing"
        ).update({"status": "pending", "error": error})
        self.db.commit()
