from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import asyncio
from app.api.routes import router
from app.core.config import settings
from app.core.database import init_db
from app.core.logging import setup_logging, get_logger
from app.workers.task_worker import TaskWorker

setup_logging()
logger = get_logger(__name__)

worker_task = None
worker = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global worker_task, worker
    
    logger.info("Starting AI Execution Hub...")
    
    init_db()
    logger.info("Database initialized")
    
    worker = TaskWorker()
    worker_task = asyncio.create_task(worker.start())
    logger.info("Background worker started")
    
    yield
    
    logger.info("Shutting down...")
    if worker:
        await worker.stop()
    if worker_task:
        worker_task.cancel()
        try:
            await worker_task
        except asyncio.CancelledError:
            pass
    logger.info("Shutdown complete")


app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description="Enterprise AI Task Execution Hub - Backend API for LLM-powered task orchestration",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router, prefix="/api/v1")


@app.get("/")
async def root():
    return {
        "message": "AI Execution Hub API",
        "version": settings.APP_VERSION,
        "docs": "/docs",
        "health": "/api/v1/health"
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.DEBUG
    )
