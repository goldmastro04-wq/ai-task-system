from openai import OpenAI
from typing import List, Dict, Any
import json
from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)


class PlanningService:
    """Uses LLM to break down complex tasks into executable steps"""
    
    def __init__(self):
        self.client = OpenAI(api_key=settings.OPENAI_API_KEY)
        self.model = settings.OPENAI_MODEL
    
    async def create_execution_plan(self, task_title: str, task_description: str) -> List[Dict[str, Any]]:
        """
        Use LLM to create a detailed execution plan with steps
        
        Returns a list of steps, each with:
        - step_number: int
        - name: str
        - description: str
        - estimated_duration: str
        - dependencies: list[int]
        """
        
        system_prompt = """You are an AI task planning assistant. Your job is to break down complex tasks into clear, executable steps.

For each task, analyze it and create a detailed execution plan with 3-10 steps.

Return your response as a JSON array of steps, where each step has:
- step_number: sequential number starting from 1
- name: short descriptive name (max 100 chars)
- description: detailed description of what to do (max 500 chars)
- estimated_duration: estimate like "5 minutes", "1 hour", etc.
- dependencies: array of step numbers this depends on (empty if none)

Example output:
[
  {
    "step_number": 1,
    "name": "Research target audience",
    "description": "Identify the target demographic for the Instagram campaign, including age, interests, and behavior patterns",
    "estimated_duration": "30 minutes",
    "dependencies": []
  },
  {
    "step_number": 2,
    "name": "Create content calendar",
    "description": "Design a 30-day posting schedule with themes, post types, and optimal posting times",
    "estimated_duration": "1 hour",
    "dependencies": [1]
  }
]

Only return valid JSON, no additional text."""

        user_prompt = f"""Task Title: {task_title}

Task Description: {task_description}

Create a detailed execution plan for this task."""

        try:
            logger.info(f"Creating execution plan for task: {task_title}")
            
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=0.7,
                max_tokens=settings.OPENAI_MAX_TOKENS
            )
            
            content = response.choices[0].message.content.strip()
            
            if content.startswith("```json"):
                content = content[7:]
            if content.endswith("```"):
                content = content[:-3]
            content = content.strip()
            
            steps = json.loads(content)
            
            if not isinstance(steps, list):
                raise ValueError("LLM response is not a list")
            
            logger.info(f"Created plan with {len(steps)} steps")
            return steps
            
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse LLM response: {e}")
            return self._create_fallback_plan(task_title, task_description)
        
        except Exception as e:
            logger.error(f"Error creating execution plan: {e}")
            return self._create_fallback_plan(task_title, task_description)
    
    def _create_fallback_plan(self, task_title: str, task_description: str) -> List[Dict[str, Any]]:
        """Fallback plan if LLM fails"""
        return [
            {
                "step_number": 1,
                "name": "Analyze task requirements",
                "description": f"Analyze the requirements for: {task_title}",
                "estimated_duration": "15 minutes",
                "dependencies": []
            },
            {
                "step_number": 2,
                "name": "Execute task",
                "description": task_description[:500],
                "estimated_duration": "1 hour",
                "dependencies": [1]
            },
            {
                "step_number": 3,
                "name": "Review and finalize",
                "description": "Review the results and ensure quality standards are met",
                "estimated_duration": "15 minutes",
                "dependencies": [2]
            }
        ]
