from typing import Dict, Any, Optional
from datetime import datetime
import uuid
from sqlalchemy.orm import Session
from app.models.task import Task, TaskStep, ExecutionLog, TaskResult, TaskStatus, StepStatus
from app.repositories.task_repository import TaskRepository
from app.services.planning_service import PlanningService
from app.queue.database_queue import DatabaseQueue
from app.core.logging import get_logger

logger = get_logger(__name__)


class TaskService:
    """Main service for task orchestration"""
    
    def __init__(self, db: Session):
        self.db = db
        self.repository = TaskRepository(db)
        self.planning_service = PlanningService()
        self.queue = DatabaseQueue(db)
    
    async def create_task(self, title: str, description: str, user_id: Optional[str] = None, 
                         priority: int = 0, metadata: Dict[str, Any] = None) -> Task:
        """Create a new task and enqueue it for processing"""
        
        task_id = str(uuid.uuid4())
        
        task = Task(
            id=task_id,
            user_id=user_id,
            title=title,
            description=description,
            status=TaskStatus.PENDING,
            priority=priority,
            task_metadata=metadata or {}
        )
        
        task = self.repository.create_task(task)
        
        self._create_log(task_id, "INFO", f"Task created: {title}")
        
        await self.queue.enqueue("task_queue", {
            "task_id": task_id,
            "action": "plan_and_execute"
        }, priority=priority)
        
        logger.info(f"Task {task_id} created and enqueued")
        return task
    
    async def plan_task(self, task_id: str) -> bool:
        """Generate execution plan for a task using LLM"""
        
        task = self.repository.get_task(task_id)
        if not task:
            logger.error(f"Task {task_id} not found")
            return False
        
        task.status = TaskStatus.PLANNING
        task.started_at = datetime.utcnow()
        self.repository.update_task(task)
        
        self._create_log(task_id, "INFO", "Starting task planning with LLM")
        
        try:
            steps_data = await self.planning_service.create_execution_plan(
                task.title, 
                task.description
            )
            
            for step_data in steps_data:
                step_id = str(uuid.uuid4())
                step = TaskStep(
                    id=step_id,
                    task_id=task_id,
                    step_number=step_data["step_number"],
                    name=step_data["name"],
                    description=step_data["description"],
                    status=StepStatus.PENDING,
                    input_data={
                        "estimated_duration": step_data.get("estimated_duration", "unknown"),
                        "dependencies": step_data.get("dependencies", [])
                    }
                )
                self.repository.create_step(step)
            
            self._create_log(task_id, "INFO", f"Created {len(steps_data)} execution steps")
            
            task.status = TaskStatus.EXECUTING
            self.repository.update_task(task)
            
            return True
            
        except Exception as e:
            logger.error(f"Error planning task {task_id}: {e}")
            task.status = TaskStatus.FAILED
            task.error_message = str(e)
            self.repository.update_task(task)
            self._create_log(task_id, "ERROR", f"Planning failed: {str(e)}")
            return False
    
    async def execute_task(self, task_id: str) -> bool:
        """Execute all steps of a task"""
        
        task = self.repository.get_task_with_details(task_id)
        if not task:
            logger.error(f"Task {task_id} not found")
            return False
        
        self._create_log(task_id, "INFO", "Starting task execution")
        
        try:
            results = []
            
            for step in sorted(task.steps, key=lambda s: s.step_number):
                step_result = await self._execute_step(task_id, step)
                results.append(step_result)
                
                if not step_result.get("success", False):
                    raise Exception(f"Step {step.step_number} failed")
            
            task_result = TaskResult(
                task_id=task_id,
                result_data={
                    "steps_completed": len(results),
                    "step_results": results
                },
                summary=f"Successfully completed {len(results)} steps"
            )
            self.repository.create_result(task_result)
            
            task.status = TaskStatus.COMPLETED
            task.completed_at = datetime.utcnow()
            self.repository.update_task(task)
            
            self._create_log(task_id, "INFO", "Task completed successfully")
            return True
            
        except Exception as e:
            logger.error(f"Error executing task {task_id}: {e}")
            task.status = TaskStatus.FAILED
            task.error_message = str(e)
            self.repository.update_task(task)
            self._create_log(task_id, "ERROR", f"Execution failed: {str(e)}")
            return False
    
    async def _execute_step(self, task_id: str, step: TaskStep) -> Dict[str, Any]:
        """Execute a single step (placeholder for actual implementation)"""
        
        step.status = StepStatus.EXECUTING
        step.started_at = datetime.utcnow()
        self.repository.update_task(step.task)
        
        self._create_log(task_id, "INFO", f"Executing step {step.step_number}: {step.name}", step.id)
        
        try:
            output = {
                "step_number": step.step_number,
                "step_name": step.name,
                "result": f"Mock execution result for: {step.description}",
                "success": True
            }
            
            step.output_data = output
            step.status = StepStatus.COMPLETED
            step.completed_at = datetime.utcnow()
            self.repository.update_task(step.task)
            
            self._create_log(task_id, "INFO", f"Completed step {step.step_number}", step.id)
            
            return output
            
        except Exception as e:
            step.status = StepStatus.FAILED
            step.error_message = str(e)
            self.repository.update_task(step.task)
            self._create_log(task_id, "ERROR", f"Step {step.step_number} failed: {str(e)}", step.id)
            return {
                "step_number": step.step_number,
                "success": False,
                "error": str(e)
            }
    
    def _create_log(self, task_id: str, level: str, message: str, step_id: Optional[str] = None):
        """Create an execution log entry"""
        log = ExecutionLog(
            task_id=task_id,
            step_id=step_id,
            level=level,
            message=message
        )
        self.repository.create_log(log)
