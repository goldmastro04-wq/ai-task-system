from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from datetime import datetime
from app.core.database import get_db
from app.schemas.task import (
    TaskCreate, TaskResponse, TaskDetailResponse, 
    TaskWithResultResponse, HealthResponse
)
from app.services.task_service import TaskService
from app.repositories.task_repository import TaskRepository
from app.models.task import TaskStatus

router = APIRouter()


@router.post("/tasks", response_model=TaskResponse, status_code=status.HTTP_201_CREATED)
async def create_task(task_data: TaskCreate, db: Session = Depends(get_db)):
    """
    Create a new task
    
    The task will be automatically queued for planning and execution.
    """
    task_service = TaskService(db)
    
    task = await task_service.create_task(
        title=task_data.title,
        description=task_data.description,
        user_id=task_data.user_id,
        priority=task_data.priority,
        metadata=task_data.metadata
    )
    
    return task


@router.get("/tasks/{task_id}", response_model=TaskDetailResponse)
async def get_task_status(task_id: str, db: Session = Depends(get_db)):
    """
    Get task status and details including execution logs
    """
    repository = TaskRepository(db)
    task = repository.get_task_with_details(task_id)
    
    if not task:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Task {task_id} not found"
        )
    
    return task


@router.get("/tasks/{task_id}/result", response_model=TaskWithResultResponse)
async def get_task_result(task_id: str, db: Session = Depends(get_db)):
    """
    Get task result (only available when task is completed)
    """
    repository = TaskRepository(db)
    task = repository.get_task_with_details(task_id)
    
    if not task:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Task {task_id} not found"
        )
    
    if task.status != TaskStatus.COMPLETED:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Task is not completed yet. Current status: {task.status.value}"
        )
    
    return task


@router.get("/tasks", response_model=List[TaskResponse])
async def list_tasks(
    status: TaskStatus = None,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    """
    List all tasks, optionally filtered by status
    """
    repository = TaskRepository(db)
    tasks = repository.get_tasks(status=status, limit=limit)
    return tasks


@router.get("/health", response_model=HealthResponse)
async def health_check(db: Session = Depends(get_db)):
    """
    Health check endpoint
    """
    try:
        db.execute("SELECT 1")
        db_status = "healthy"
    except Exception:
        db_status = "unhealthy"
    
    return {
        "status": "running",
        "version": "1.0.0",
        "database": db_status,
        "workers": "running",
        "timestamp": datetime.utcnow()
    }
