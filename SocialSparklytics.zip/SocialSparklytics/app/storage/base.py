from abc import ABC, abstractmethod
from typing import Optional, BinaryIO


class StorageInterface(ABC):
    """Abstract interface for storage systems (local filesystem, S3, MinIO)"""
    
    @abstractmethod
    async def save_file(self, file_path: str, content: bytes) -> str:
        """Save file and return the storage path"""
        pass
    
    @abstractmethod
    async def get_file(self, file_path: str) -> Optional[bytes]:
        """Retrieve file content"""
        pass
    
    @abstractmethod
    async def delete_file(self, file_path: str) -> bool:
        """Delete a file"""
        pass
    
    @abstractmethod
    async def file_exists(self, file_path: str) -> bool:
        """Check if file exists"""
        pass
    
    @abstractmethod
    async def list_files(self, prefix: str = "") -> list[str]:
        """List all files with given prefix"""
        pass
