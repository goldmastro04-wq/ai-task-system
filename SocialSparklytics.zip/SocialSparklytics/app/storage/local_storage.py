import os
import aiofiles
from typing import Optional
from pathlib import Path
from app.storage.base import StorageInterface
from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)


class LocalStorage(StorageInterface):
    """Local filesystem storage (portable, can be replaced with S3 later)"""
    
    def __init__(self, base_path: str = None):
        self.base_path = Path(base_path or settings.STORAGE_PATH)
        self.base_path.mkdir(parents=True, exist_ok=True)
        logger.info(f"Initialized local storage at {self.base_path}")
    
    def _get_full_path(self, file_path: str) -> Path:
        return self.base_path / file_path
    
    async def save_file(self, file_path: str, content: bytes) -> str:
        full_path = self._get_full_path(file_path)
        full_path.parent.mkdir(parents=True, exist_ok=True)
        
        async with aiofiles.open(full_path, 'wb') as f:
            await f.write(content)
        
        logger.info(f"Saved file to {full_path}")
        return str(full_path)
    
    async def get_file(self, file_path: str) -> Optional[bytes]:
        full_path = self._get_full_path(file_path)
        
        if not full_path.exists():
            return None
        
        async with aiofiles.open(full_path, 'rb') as f:
            content = await f.read()
        
        return content
    
    async def delete_file(self, file_path: str) -> bool:
        full_path = self._get_full_path(file_path)
        
        if full_path.exists():
            full_path.unlink()
            logger.info(f"Deleted file {full_path}")
            return True
        
        return False
    
    async def file_exists(self, file_path: str) -> bool:
        full_path = self._get_full_path(file_path)
        return full_path.exists()
    
    async def list_files(self, prefix: str = "") -> list[str]:
        search_path = self._get_full_path(prefix)
        
        if search_path.is_file():
            return [str(search_path.relative_to(self.base_path))]
        
        if not search_path.exists():
            return []
        
        files = []
        for item in search_path.rglob('*'):
            if item.is_file():
                files.append(str(item.relative_to(self.base_path)))
        
        return files
