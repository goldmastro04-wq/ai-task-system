import asyncio
import time
from sqlalchemy.orm import Session
from app.core.database import SessionLocal
from app.core.logging import get_logger
from app.services.task_service import TaskService
from app.queue.database_queue import DatabaseQueue
from app.core.config import settings

logger = get_logger(__name__)


class TaskWorker:
    """Background worker that processes tasks from the queue"""
    
    def __init__(self):
        self.running = False
        self.poll_interval = settings.WORKER_POLL_INTERVAL
    
    async def start(self):
        """Start the worker loop"""
        self.running = True
        logger.info("Task worker started")
        
        while self.running:
            try:
                await self._process_next_task()
                await asyncio.sleep(self.poll_interval)
            except Exception as e:
                logger.error(f"Worker error: {e}")
                await asyncio.sleep(self.poll_interval)
    
    async def stop(self):
        """Stop the worker"""
        self.running = False
        logger.info("Task worker stopped")
    
    async def _process_next_task(self):
        """Process the next task from the queue"""
        db: Session = SessionLocal()
        
        try:
            queue = DatabaseQueue(db)
            task_data = await queue.dequeue("task_queue")
            
            if not task_data:
                return
            
            task_id = task_data.get("task_id")
            action = task_data.get("action")
            
            logger.info(f"Processing task {task_id} with action {action}")
            
            task_service = TaskService(db)
            
            if action == "plan_and_execute":
                success = await task_service.plan_task(task_id)
                if success:
                    success = await task_service.execute_task(task_id)
            elif action == "execute":
                success = await task_service.execute_task(task_id)
            else:
                logger.warning(f"Unknown action: {action}")
                success = False
            
            if success:
                queue.mark_completed(task_id)
                logger.info(f"Task {task_id} completed successfully")
            else:
                queue.mark_failed(task_id, "Task execution failed")
                logger.error(f"Task {task_id} failed")
        
        except Exception as e:
            logger.error(f"Error processing task: {e}")
        
        finally:
            db.close()


async def run_worker():
    """Entry point for running the worker"""
    worker = TaskWorker()
    try:
        await worker.start()
    except KeyboardInterrupt:
        await worker.stop()


if __name__ == "__main__":
    asyncio.run(run_worker())
