from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime
from app.models.task import TaskStatus, StepStatus


class TaskCreate(BaseModel):
    title: str = Field(..., min_length=1, max_length=500, description="Task title")
    description: str = Field(..., min_length=1, description="Detailed task description")
    user_id: Optional[str] = None
    priority: int = Field(default=0, ge=0, le=10)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class TaskStepResponse(BaseModel):
    id: str
    step_number: int
    name: str
    description: str
    status: StepStatus
    created_at: datetime
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    input_data: Dict[str, Any] = {}
    output_data: Dict[str, Any] = {}
    error_message: Optional[str] = None
    
    class Config:
        from_attributes = True


class ExecutionLogResponse(BaseModel):
    id: int
    step_id: Optional[str] = None
    level: str
    message: str
    details: Dict[str, Any] = {}
    created_at: datetime
    
    class Config:
        from_attributes = True


class TaskResponse(BaseModel):
    id: str
    user_id: Optional[str] = None
    title: str
    description: str
    status: TaskStatus
    priority: int
    created_at: datetime
    updated_at: datetime
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    error_message: Optional[str] = None
    retry_count: int
    task_metadata: Dict[str, Any] = {}
    steps: List[TaskStepResponse] = []
    
    class Config:
        from_attributes = True


class TaskDetailResponse(TaskResponse):
    logs: List[ExecutionLogResponse] = []


class TaskResultResponse(BaseModel):
    id: int
    task_id: str
    result_data: Dict[str, Any]
    file_paths: List[str] = []
    summary: Optional[str] = None
    created_at: datetime
    
    class Config:
        from_attributes = True


class TaskWithResultResponse(TaskResponse):
    result: Optional[TaskResultResponse] = None


class HealthResponse(BaseModel):
    status: str
    version: str
    database: str
    workers: str
    timestamp: datetime
