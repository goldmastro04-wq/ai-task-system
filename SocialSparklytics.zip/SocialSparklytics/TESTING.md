# API Testing Guide

This guide provides comprehensive examples for testing the AI Execution Hub API using curl and Postman.

## Base URL

When running locally on Replit:
```
https://your-replit-app.repl.co
```

Or for local testing:
```
http://localhost:5000
```

## API Endpoints

### 1. Health Check

Check if the API is running and healthy.

**curl:**
```bash
curl -X GET "https://your-replit-app.repl.co/api/v1/health"
```

**Expected Response:**
```json
{
  "status": "running",
  "version": "1.0.0",
  "database": "healthy",
  "workers": "running",
  "timestamp": "2025-11-23T21:50:07.123456"
}
```

---

### 2. Create a Task

Submit a new task for processing. The LLM will automatically plan and execute it.

**curl:**
```bash
curl -X POST "https://your-replit-app.repl.co/api/v1/tasks" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Create Instagram marketing strategy",
    "description": "Design a comprehensive 30-day Instagram marketing plan for a coffee shop startup, including content calendar, post ideas, hashtag strategy, and engagement tactics",
    "priority": 5,
    "metadata": {
      "business_type": "coffee_shop",
      "target_audience": "young professionals"
    }
  }'
```

**Postman:**
- Method: POST
- URL: `https://your-replit-app.repl.co/api/v1/tasks`
- Headers:
  - Content-Type: application/json
- Body (raw JSON):
```json
{
  "title": "Create Instagram marketing strategy",
  "description": "Design a comprehensive 30-day Instagram marketing plan for a coffee shop startup",
  "priority": 5,
  "metadata": {
    "business_type": "coffee_shop"
  }
}
```

**Expected Response:**
```json
{
  "id": "123e4567-e89b-12d3-a456-426614174000",
  "user_id": null,
  "title": "Create Instagram marketing strategy",
  "description": "Design a comprehensive 30-day Instagram marketing plan...",
  "status": "pending",
  "priority": 5,
  "created_at": "2025-11-23T21:50:07.123456",
  "updated_at": "2025-11-23T21:50:07.123456",
  "started_at": null,
  "completed_at": null,
  "error_message": null,
  "retry_count": 0,
  "task_metadata": {
    "business_type": "coffee_shop",
    "target_audience": "young professionals"
  },
  "steps": []
}
```

**Note:** Save the `id` value from the response - you'll need it for subsequent requests.

---

### 3. Get Task Status

Monitor the progress of your task and see execution details.

**curl:**
```bash
TASK_ID="123e4567-e89b-12d3-a456-426614174000"
curl -X GET "https://your-replit-app.repl.co/api/v1/tasks/$TASK_ID"
```

**Postman:**
- Method: GET
- URL: `https://your-replit-app.repl.co/api/v1/tasks/123e4567-e89b-12d3-a456-426614174000`

**Expected Response (during planning):**
```json
{
  "id": "123e4567-e89b-12d3-a456-426614174000",
  "title": "Create Instagram marketing strategy",
  "status": "planning",
  "started_at": "2025-11-23T21:50:08.123456",
  "steps": [],
  "logs": [
    {
      "id": 1,
      "step_id": null,
      "level": "INFO",
      "message": "Task created: Create Instagram marketing strategy",
      "details": {},
      "created_at": "2025-11-23T21:50:07.123456"
    },
    {
      "id": 2,
      "step_id": null,
      "level": "INFO",
      "message": "Starting task planning with LLM",
      "details": {},
      "created_at": "2025-11-23T21:50:08.123456"
    }
  ]
}
```

**Expected Response (during execution):**
```json
{
  "id": "123e4567-e89b-12d3-a456-426614174000",
  "title": "Create Instagram marketing strategy",
  "status": "executing",
  "steps": [
    {
      "id": "step-uuid-1",
      "step_number": 1,
      "name": "Research target audience",
      "description": "Identify the target demographic for the Instagram campaign",
      "status": "completed",
      "created_at": "2025-11-23T21:50:09.123456",
      "started_at": "2025-11-23T21:50:10.123456",
      "completed_at": "2025-11-23T21:50:15.123456",
      "input_data": {
        "estimated_duration": "30 minutes",
        "dependencies": []
      },
      "output_data": {
        "step_number": 1,
        "step_name": "Research target audience",
        "result": "Mock execution result for: Identify the target demographic...",
        "success": true
      },
      "error_message": null
    },
    {
      "id": "step-uuid-2",
      "step_number": 2,
      "name": "Create content calendar",
      "description": "Design a 30-day posting schedule with themes",
      "status": "executing",
      "created_at": "2025-11-23T21:50:09.123456",
      "started_at": "2025-11-23T21:50:16.123456",
      "completed_at": null
    }
  ],
  "logs": [...]
}
```

---

### 4. Get Task Result

Retrieve the final result once the task is completed.

**curl:**
```bash
TASK_ID="123e4567-e89b-12d3-a456-426614174000"
curl -X GET "https://your-replit-app.repl.co/api/v1/tasks/$TASK_ID/result"
```

**Postman:**
- Method: GET
- URL: `https://your-replit-app.repl.co/api/v1/tasks/123e4567-e89b-12d3-a456-426614174000/result`

**Expected Response (when completed):**
```json
{
  "id": "123e4567-e89b-12d3-a456-426614174000",
  "title": "Create Instagram marketing strategy",
  "status": "completed",
  "completed_at": "2025-11-23T21:51:30.123456",
  "steps": [...],
  "result": {
    "id": 1,
    "task_id": "123e4567-e89b-12d3-a456-426614174000",
    "result_data": {
      "steps_completed": 5,
      "step_results": [
        {
          "step_number": 1,
          "step_name": "Research target audience",
          "result": "Mock execution result...",
          "success": true
        },
        ...
      ]
    },
    "file_paths": [],
    "summary": "Successfully completed 5 steps",
    "created_at": "2025-11-23T21:51:30.123456"
  }
}
```

**Error Response (if task not completed):**
```json
{
  "detail": "Task is not completed yet. Current status: executing"
}
```

---

### 5. List All Tasks

Get a list of all tasks, optionally filtered by status.

**curl (all tasks):**
```bash
curl -X GET "https://your-replit-app.repl.co/api/v1/tasks"
```

**curl (filter by status):**
```bash
curl -X GET "https://your-replit-app.repl.co/api/v1/tasks?status=completed&limit=10"
```

**Postman:**
- Method: GET
- URL: `https://your-replit-app.repl.co/api/v1/tasks?status=completed&limit=10`

**Query Parameters:**
- `status` (optional): Filter by status - `pending`, `planning`, `executing`, `completed`, `failed`
- `limit` (optional): Max number of results (default: 100)

**Expected Response:**
```json
[
  {
    "id": "123e4567-e89b-12d3-a456-426614174000",
    "title": "Create Instagram marketing strategy",
    "status": "completed",
    "priority": 5,
    "created_at": "2025-11-23T21:50:07.123456",
    ...
  },
  {
    "id": "another-task-id",
    "title": "Another task",
    "status": "executing",
    ...
  }
]
```

---

## Example Test Scenarios

### Scenario 1: Complete Task Workflow

```bash
# 1. Create a task
RESPONSE=$(curl -s -X POST "https://your-replit-app.repl.co/api/v1/tasks" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Generate social media content",
    "description": "Create 10 Instagram post ideas for a fitness brand"
  }')

# Extract task ID (requires jq)
TASK_ID=$(echo $RESPONSE | jq -r '.id')
echo "Task created: $TASK_ID"

# 2. Wait a few seconds for processing
sleep 5

# 3. Check status
curl -s "https://your-replit-app.repl.co/api/v1/tasks/$TASK_ID" | jq '.status'

# 4. Wait for completion (poll every 5 seconds)
while true; do
  STATUS=$(curl -s "https://your-replit-app.repl.co/api/v1/tasks/$TASK_ID" | jq -r '.status')
  echo "Current status: $STATUS"
  
  if [ "$STATUS" == "completed" ] || [ "$STATUS" == "failed" ]; then
    break
  fi
  
  sleep 5
done

# 5. Get final result
curl -s "https://your-replit-app.repl.co/api/v1/tasks/$TASK_ID/result" | jq '.'
```

### Scenario 2: Multiple Tasks with Different Priorities

```bash
# High priority task
curl -X POST "https://your-replit-app.repl.co/api/v1/tasks" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Urgent: Launch campaign",
    "description": "Prepare emergency marketing campaign",
    "priority": 10
  }'

# Low priority task
curl -X POST "https://your-replit-app.repl.co/api/v1/tasks" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Research competitors",
    "description": "Analyze top 5 competitors",
    "priority": 2
  }'

# List all tasks to see priority ordering
curl -X GET "https://your-replit-app.repl.co/api/v1/tasks"
```

---

## Interactive API Documentation

FastAPI provides interactive API documentation:

1. **Swagger UI:** `https://your-replit-app.repl.co/docs`
2. **ReDoc:** `https://your-replit-app.repl.co/redoc`

Both interfaces allow you to:
- Browse all endpoints
- Test requests directly from the browser
- View request/response schemas
- See example values

---

## Task Statuses

| Status | Description |
|--------|-------------|
| `pending` | Task created and waiting in queue |
| `planning` | LLM is breaking down the task into steps |
| `executing` | Worker is executing the planned steps |
| `completed` | All steps completed successfully |
| `failed` | Task execution failed (check error_message) |

---

## Error Responses

### 404 Not Found
```json
{
  "detail": "Task 123e4567-e89b-12d3-a456-426614174000 not found"
}
```

### 400 Bad Request
```json
{
  "detail": "Task is not completed yet. Current status: executing"
}
```

### 422 Validation Error
```json
{
  "detail": [
    {
      "loc": ["body", "title"],
      "msg": "field required",
      "type": "value_error.missing"
    }
  ]
}
```

---

## Tips for Testing

1. **Use jq for JSON formatting:**
   ```bash
   curl -s "https://your-replit-app.repl.co/api/v1/tasks/$TASK_ID" | jq '.'
   ```

2. **Save task IDs to variables:**
   ```bash
   TASK_ID="your-task-id-here"
   ```

3. **Check logs for detailed execution info:**
   - The `/tasks/{id}` endpoint includes execution logs
   - Logs show each step of the process

4. **Monitor worker activity:**
   - Check the server console for worker logs
   - Worker polls every 2 seconds for new tasks

5. **Test with OPENAI_API_KEY:**
   - Make sure you've set your OpenAI API key
   - Without it, LLM planning will use fallback plans

---

## Postman Collection

You can import this JSON as a Postman collection:

```json
{
  "info": {
    "name": "AI Execution Hub API",
    "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
  },
  "item": [
    {
      "name": "Health Check",
      "request": {
        "method": "GET",
        "url": "{{base_url}}/api/v1/health"
      }
    },
    {
      "name": "Create Task",
      "request": {
        "method": "POST",
        "url": "{{base_url}}/api/v1/tasks",
        "header": [{"key": "Content-Type", "value": "application/json"}],
        "body": {
          "mode": "raw",
          "raw": "{\n  \"title\": \"Test Task\",\n  \"description\": \"This is a test task\",\n  \"priority\": 5\n}"
        }
      }
    },
    {
      "name": "Get Task Status",
      "request": {
        "method": "GET",
        "url": "{{base_url}}/api/v1/tasks/{{task_id}}"
      }
    },
    {
      "name": "Get Task Result",
      "request": {
        "method": "GET",
        "url": "{{base_url}}/api/v1/tasks/{{task_id}}/result"
      }
    },
    {
      "name": "List Tasks",
      "request": {
        "method": "GET",
        "url": "{{base_url}}/api/v1/tasks?limit=10"
      }
    }
  ],
  "variable": [
    {
      "key": "base_url",
      "value": "https://your-replit-app.repl.co"
    },
    {
      "key": "task_id",
      "value": ""
    }
  ]
}
```

Save this to a `.json` file and import into Postman.
