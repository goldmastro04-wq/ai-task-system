# AI Execution Hub - Architecture Documentation

## Overview

The AI Execution Hub is an enterprise-grade task orchestration system that uses Large Language Models (LLMs) to intelligently plan and execute complex tasks. Built with a modular, microservices-ready architecture on Replit, it's designed to be portable to containerized environments like Docker, Kubernetes, AWS, or Railway.

## Architecture Diagram

```
┌─────────────┐
│   Client    │ (curl, Postman, Future Web/Mobile App)
└──────┬──────┘
       │
       │ HTTP/REST
       │
┌──────▼──────────────────────────────────────────────┐
│           FastAPI Application (Port 5000)           │
│  ┌──────────────────────────────────────────────┐  │
│  │         API Layer (controllers/routes)        │  │
│  └───────────────────┬──────────────────────────┘  │
│                      │                               │
│  ┌───────────────────▼──────────────────────────┐  │
│  │         Service Layer (business logic)        │  │
│  │  • TaskService (orchestration)                │  │
│  │  • PlanningService (LLM integration)          │  │
│  └───────────────────┬──────────────────────────┘  │
│                      │                               │
│  ┌──────────────────┴───────────┬─────────────┐   │
│  │                              │             │   │
│  ▼                              ▼             ▼   │
│ ┌──────────┐  ┌──────────────┐  ┌──────────────┐ │
│ │Repository│  │Queue Manager │  │Storage Layer │ │
│ │  Layer   │  │(DB Queue)    │  │(Local/S3)    │ │
│ └────┬─────┘  └──────┬───────┘  └──────────────┘ │
└──────┼────────────────┼───────────────────────────┘
       │                │
       ▼                ▼
┌────────────┐   ┌──────────────┐
│ PostgreSQL │   │Queue Table   │
│  Database  │◄──┤(queue_items) │
└────────────┘   └──────┬───────┘
                        │
                        │ Poll every 2s
                        │
                  ┌─────▼──────┐
                  │   Worker   │
                  │  Process   │
                  │            │
                  │ • Plan     │
                  │ • Execute  │
                  │ • Log      │
                  └─────┬──────┘
                        │
                        ▼
                  ┌─────────────┐
                  │  OpenAI     │
                  │  API (LLM)  │
                  └─────────────┘
```

## Technology Stack

### Core Framework
- **FastAPI** - Modern, high-performance web framework
- **Python 3.11** - Programming language
- **Uvicorn** - ASGI server with async support
- **SQLAlchemy 2.0** - ORM for database operations
- **Pydantic** - Data validation and settings management

### Database
- **PostgreSQL** - Relational database (managed by Replit)
- Tables: `tasks`, `task_steps`, `execution_logs`, `task_results`, `queue_items`

### AI/ML
- **OpenAI API** - LLM for task planning (GPT-4o-mini)
- **Custom Planning Service** - Breaks down complex tasks into executable steps

### Background Processing
- **Asyncio** - Python's built-in async framework
- **Database-backed Queue** - Custom queue implementation (portable to Redis/RabbitMQ)
- **Background Workers** - Separate async processes for task execution

### Storage
- **Local Filesystem** - Current implementation
- **S3-ready Interface** - Abstraction layer for future cloud storage

## Project Structure

```
/
├── app/
│   ├── api/                    # API Layer
│   │   ├── __init__.py
│   │   └── routes.py          # FastAPI route handlers
│   │
│   ├── services/              # Business Logic Layer
│   │   ├── __init__.py
│   │   ├── task_service.py    # Task orchestration
│   │   └── planning_service.py # LLM-powered planning
│   │
│   ├── workers/               # Background Workers
│   │   ├── __init__.py
│   │   └── task_worker.py     # Async task processor
│   │
│   ├── models/                # Database Models
│   │   ├── __init__.py
│   │   └── task.py            # SQLAlchemy models
│   │
│   ├── schemas/               # Request/Response Schemas
│   │   ├── __init__.py
│   │   └── task.py            # Pydantic schemas
│   │
│   ├── repositories/          # Data Access Layer
│   │   ├── __init__.py
│   │   └── task_repository.py # CRUD operations
│   │
│   ├── queue/                 # Queue Abstraction
│   │   ├── __init__.py
│   │   ├── base.py           # Queue interface
│   │   └── database_queue.py  # DB implementation
│   │
│   ├── storage/               # Storage Abstraction
│   │   ├── __init__.py
│   │   ├── base.py           # Storage interface
│   │   └── local_storage.py   # Local filesystem
│   │
│   ├── core/                  # Core Configuration
│   │   ├── __init__.py
│   │   ├── config.py         # Settings & environment
│   │   ├── database.py       # DB connection
│   │   └── logging.py        # Logging setup
│   │
│   ├── tests/                 # Test Suite
│   │   └── __init__.py
│   │
│   └── main.py                # FastAPI application entry
│
├── migrations/                # Database Migrations (future)
├── scripts/                   # Utility Scripts
├── storage/                   # Local file storage (gitignored)
│
├── requirements.txt           # Python dependencies
├── .env.example              # Environment variables template
├── .gitignore                # Git ignore rules
├── TESTING.md                # API testing guide
├── ARCHITECTURE.md           # This file
└── README.md                 # Project documentation
```

## Layered Architecture

### 1. API Layer (`app/api/`)

**Responsibility:** Handle HTTP requests/responses, input validation, error handling

**Components:**
- `routes.py` - FastAPI router with endpoint definitions
- Request validation via Pydantic schemas
- Response serialization
- HTTP status code management

**Endpoints:**
- `POST /api/v1/tasks` - Create task
- `GET /api/v1/tasks/{id}` - Get task status
- `GET /api/v1/tasks/{id}/result` - Get task result
- `GET /api/v1/tasks` - List tasks
- `GET /api/v1/health` - Health check

### 2. Service Layer (`app/services/`)

**Responsibility:** Business logic, orchestration, external API integration

**Components:**

**TaskService** (`task_service.py`):
- Task creation and lifecycle management
- Coordination between planning and execution
- Error handling and retry logic
- Logging and state management

**PlanningService** (`planning_service.py`):
- LLM integration (OpenAI)
- Task decomposition into executable steps
- Fallback planning for LLM failures
- Prompt engineering

### 3. Worker Layer (`app/workers/`)

**Responsibility:** Background task processing, async execution

**Components:**

**TaskWorker** (`task_worker.py`):
- Polls queue every 2 seconds
- Executes tasks asynchronously
- Handles task planning → execution flow
- Error recovery and retries
- Independent process lifecycle

### 4. Repository Layer (`app/repositories/`)

**Responsibility:** Data access, CRUD operations, database queries

**Components:**

**TaskRepository** (`task_repository.py`):
- Create/Read/Update/Delete tasks
- Query optimization with eager loading
- Transaction management
- Data integrity enforcement

### 5. Queue Layer (`app/queue/`)

**Responsibility:** Task queue management (portable abstraction)

**Components:**

**QueueInterface** (`base.py`):
- Abstract interface for queue systems
- Supports: Database, Redis, RabbitMQ (future)

**DatabaseQueue** (`database_queue.py`):
- Current implementation using PostgreSQL
- Priority-based task ordering
- Status tracking (pending/processing/completed)
- Easy migration to Redis/RabbitMQ

### 6. Storage Layer (`app/storage/`)

**Responsibility:** File storage management (portable abstraction)

**Components:**

**StorageInterface** (`base.py`):
- Abstract interface for storage systems
- Supports: Local, S3, MinIO (future)

**LocalStorage** (`local_storage.py`):
- Current implementation using local filesystem
- Async file operations with aiofiles
- Directory management
- Easy migration to S3

### 7. Core Layer (`app/core/`)

**Responsibility:** Configuration, database, logging, dependencies

**Components:**
- `config.py` - Environment-based configuration
- `database.py` - SQLAlchemy setup and session management
- `logging.py` - Structured logging configuration

## Data Models

### Task
```python
- id: UUID (primary key)
- user_id: String (nullable)
- title: String (max 500)
- description: Text
- status: Enum (pending, planning, executing, completed, failed)
- priority: Integer (0-10)
- created_at: DateTime
- updated_at: DateTime
- started_at: DateTime (nullable)
- completed_at: DateTime (nullable)
- error_message: Text (nullable)
- retry_count: Integer
- task_metadata: JSON
```

### TaskStep
```python
- id: UUID (primary key)
- task_id: UUID (foreign key)
- step_number: Integer
- name: String (max 500)
- description: Text
- status: Enum (pending, executing, completed, failed, skipped)
- created_at: DateTime
- started_at: DateTime (nullable)
- completed_at: DateTime (nullable)
- input_data: JSON
- output_data: JSON
- error_message: Text (nullable)
```

### ExecutionLog
```python
- id: Integer (auto-increment)
- task_id: UUID (foreign key)
- step_id: UUID (nullable)
- level: String (INFO, WARNING, ERROR)
- message: Text
- details: JSON
- created_at: DateTime
```

### TaskResult
```python
- id: Integer (auto-increment)
- task_id: UUID (foreign key, unique)
- result_data: JSON
- file_paths: JSON (array)
- summary: Text
- created_at: DateTime
```

### QueueItem
```python
- id: Integer (auto-increment)
- queue_name: String
- task_id: String
- task_data: JSON
- priority: Integer
- status: String (pending, processing, completed)
- created_at: DateTime
- processed_at: DateTime (nullable)
- error: Text (nullable)
```

## Task Execution Flow

1. **Task Creation**
   - Client sends POST request to `/api/v1/tasks`
   - API validates request with Pydantic schema
   - TaskService creates Task record in database
   - Task enqueued with priority
   - Returns task ID to client

2. **Task Planning**
   - Worker polls queue, dequeues task
   - TaskService updates status to "planning"
   - PlanningService calls OpenAI LLM
   - LLM breaks down task into 3-10 steps
   - Steps saved to database as TaskStep records
   - Status updated to "executing"

3. **Task Execution**
   - Worker executes each step sequentially
   - Each step: pending → executing → completed/failed
   - Execution logs created for each action
   - Results stored in step.output_data
   - Errors trigger retry logic (max 3 retries)

4. **Task Completion**
   - All steps completed successfully
   - TaskResult created with aggregated results
   - Task status set to "completed"
   - Completion timestamp recorded
   - Client can retrieve results via `/api/v1/tasks/{id}/result`

## Configuration Management

### Environment Variables

```bash
# Database (auto-provided by Replit)
DATABASE_URL=postgresql://...

# OpenAI (required)
OPENAI_API_KEY=sk-...

# Application
APP_NAME=AI Execution Hub
DEBUG=True
LOG_LEVEL=INFO

# Server
HOST=0.0.0.0
PORT=5000

# Worker
WORKER_CONCURRENCY=3
WORKER_POLL_INTERVAL=2
TASK_TIMEOUT=300
MAX_RETRIES=3

# Storage
STORAGE_TYPE=local
STORAGE_PATH=./storage

# AWS S3 (future)
AWS_ACCESS_KEY_ID=
AWS_SECRET_ACCESS_KEY=
AWS_S3_BUCKET=
AWS_REGION=us-east-1
```

### Settings Class
- Uses `pydantic-settings` for type-safe configuration
- Loads from environment variables
- Provides defaults for development
- Cached with `@lru_cache()`

## Migration to Docker/Microservices

### Current Monolithic Setup (Replit)
```
Single Container:
- FastAPI application
- Background worker (in-process)
- Database (managed external service)
- Local storage
```

### Future Microservices Setup (Docker/Kubernetes)

**docker-compose.yml structure:**

```yaml
services:
  api:
    build: .
    command: uvicorn app.main:app --host 0.0.0.0 --port 8000
    ports:
      - "8000:8000"
    environment:
      - DATABASE_URL=postgresql://postgres:password@db:5432/aiexec
      - REDIS_URL=redis://redis:6379/0
      - OPENAI_API_KEY=${OPENAI_API_KEY}
      - QUEUE_TYPE=redis
      - STORAGE_TYPE=s3
    depends_on:
      - db
      - redis
      - minio

  worker:
    build: .
    command: python -m app.workers.task_worker
    environment:
      - DATABASE_URL=postgresql://postgres:password@db:5432/aiexec
      - REDIS_URL=redis://redis:6379/0
      - OPENAI_API_KEY=${OPENAI_API_KEY}
    depends_on:
      - db
      - redis
    deploy:
      replicas: 3  # Scale workers independently

  db:
    image: postgres:16
    environment:
      POSTGRES_DB: aiexec
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: password
    volumes:
      - postgres_data:/var/lib/postgresql/data

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"

  minio:
    image: minio/minio
    command: server /data --console-address ":9001"
    environment:
      MINIO_ROOT_USER: minioadmin
      MINIO_ROOT_PASSWORD: minioadmin
    ports:
      - "9000:9000"
      - "9001:9001"
    volumes:
      - minio_data:/data

volumes:
  postgres_data:
  minio_data:
```

### Migration Steps

1. **No Code Changes Required**
   - Architecture is already abstraction-based
   - Queue interface supports Redis (just change `QUEUE_TYPE=redis`)
   - Storage interface supports S3 (just change `STORAGE_TYPE=s3`)

2. **Add Redis Queue Implementation**
   ```python
   # app/queue/redis_queue.py (future)
   class RedisQueue(QueueInterface):
       def __init__(self, redis_url):
           self.redis = redis.from_url(redis_url)
       # Implementation...
   ```

3. **Add S3 Storage Implementation**
   ```python
   # app/storage/s3_storage.py (future)
   class S3Storage(StorageInterface):
       def __init__(self, bucket_name):
           self.s3 = boto3.client('s3')
       # Implementation...
   ```

4. **Update Configuration Factory**
   ```python
   # app/core/config.py
   def get_queue():
       if settings.QUEUE_TYPE == "redis":
           return RedisQueue(settings.REDIS_URL)
       return DatabaseQueue()
   
   def get_storage():
       if settings.STORAGE_TYPE == "s3":
           return S3Storage(settings.AWS_S3_BUCKET)
       return LocalStorage()
   ```

5. **Deploy with Docker Compose**
   ```bash
   docker-compose up -d
   docker-compose logs -f worker  # Monitor workers
   ```

### Benefits of This Architecture

1. **Modularity** - Each layer has clear responsibilities
2. **Testability** - Easy to unit test with dependency injection
3. **Scalability** - Workers can be scaled independently
4. **Portability** - Abstraction layers enable easy infrastructure changes
5. **Maintainability** - Clean separation of concerns
6. **Flexibility** - Swap implementations without affecting other layers

## Performance Considerations

### Current Setup
- Single worker polling every 2 seconds
- Synchronous step execution
- Database-backed queue (suitable for moderate load)

### Production Optimizations
1. **Multiple Workers** - Run 3-10 workers in parallel
2. **Redis Queue** - Replace database queue with Redis for higher throughput
3. **Parallel Step Execution** - Execute independent steps concurrently
4. **Result Caching** - Cache completed task results
5. **Database Indexing** - Index on `status`, `created_at`, `priority`
6. **Connection Pooling** - Configure SQLAlchemy pool size
7. **Rate Limiting** - Add rate limits to API endpoints

## Security Considerations

### Current Implementation
- CORS enabled (currently open for development)
- Environment-based secrets
- Database connection pooling
- SQL injection protection (via SQLAlchemy)

### Production Requirements
1. **Authentication** - Add JWT tokens or API keys
2. **Authorization** - User-based task access control
3. **Rate Limiting** - Prevent API abuse
4. **HTTPS Only** - Enforce TLS encryption
5. **Secret Management** - Use AWS Secrets Manager or HashiCorp Vault
6. **Input Sanitization** - Additional validation layers
7. **Audit Logging** - Track all API access

## Monitoring & Observability

### Current Logging
- Structured logging with Python's `logging` module
- Console output (stdout)
- Log levels: INFO, WARNING, ERROR

### Production Monitoring (Future)
1. **Metrics** - Prometheus + Grafana
   - Task queue length
   - Worker processing time
   - API response times
   - Error rates
   
2. **Distributed Tracing** - OpenTelemetry
   - Request → Queue → Worker → LLM flow
   
3. **Alerting** - PagerDuty / Slack
   - Worker failures
   - Queue backlog
   - Database connection issues

4. **Log Aggregation** - ELK Stack or Datadog
   - Centralized log search
   - Error pattern detection

## Cost Estimation

### OpenAI API Costs (per task)
- Model: GPT-4o-mini
- Planning: ~500-1000 tokens ($0.0015-$0.003)
- Execution (if AI-generated): ~2000-4000 tokens ($0.006-$0.012)
- **Estimated: $0.01-$0.02 per task**

### Infrastructure (Monthly)
- **Replit (Current)**: Free / $20 Core plan
- **AWS (Production)**:
  - EC2 (t3.medium × 2): ~$60
  - RDS PostgreSQL (db.t3.micro): ~$15
  - ElastiCache Redis (cache.t3.micro): ~$12
  - S3 Storage (100 GB): ~$2
  - **Total: ~$90/month + compute costs**

### Scaling
- 1000 tasks/day: ~$10-20/day OpenAI + $3/day infrastructure
- 10,000 tasks/day: ~$100-200/day OpenAI + $10/day infrastructure

## Future Enhancements

### Phase 2: Enhanced Features
- [ ] Redis/RabbitMQ queue implementation
- [ ] S3/MinIO storage implementation
- [ ] User authentication (JWT)
- [ ] Task cancellation endpoint
- [ ] WebSocket support for real-time updates
- [ ] Task scheduling (cron-like)
- [ ] Result caching

### Phase 3: Enterprise Features
- [ ] Multi-tenancy support
- [ ] Role-based access control (RBAC)
- [ ] API rate limiting
- [ ] Billing integration (Stripe)
- [ ] Usage quotas per user
- [ ] Advanced retry strategies
- [ ] Task dependencies (DAG)
- [ ] Workflow templates

### Phase 4: Advanced AI
- [ ] Multi-LLM support (Claude, Gemini)
- [ ] Fine-tuned models for specific tasks
- [ ] Agent-based execution
- [ ] Human-in-the-loop approvals
- [ ] Quality scoring
- [ ] A/B testing for prompts

## Contributing

When contributing to this codebase:

1. **Follow the layer structure** - Don't bypass abstractions
2. **Use interfaces** - Keep implementations swappable
3. **Write tests** - Especially for service layer
4. **Document changes** - Update this file when changing architecture
5. **Type hints** - Use Python type annotations
6. **Async-first** - Use `async/await` for I/O operations

## References

- [FastAPI Documentation](https://fastapi.tiangolo.com/)
- [SQLAlchemy Documentation](https://docs.sqlalchemy.org/)
- [OpenAI API Reference](https://platform.openai.com/docs/api-reference)
- [Pydantic Documentation](https://docs.pydantic.dev/)
- [Docker Compose Documentation](https://docs.docker.com/compose/)
