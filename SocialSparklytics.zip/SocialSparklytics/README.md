# AI Execution Hub 🤖

> Enterprise-grade AI task orchestration system with LLM-powered planning and execution

[![Python](https://img.shields.io/badge/Python-3.11-blue.svg)](https://www.python.org/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.115-green.svg)](https://fastapi.tiangolo.com/)
[![License](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

## Overview

AI Execution Hub is a production-ready backend system that uses Large Language Models to intelligently break down complex tasks into executable steps and manage their automated execution. Built with enterprise architecture patterns, it's designed to scale from a single Replit instance to a full microservices deployment.

### Key Features

✨ **LLM-Powered Planning** - Automatically decomposes complex tasks into 3-10 actionable steps using OpenAI
🔄 **Background Processing** - Async workers execute tasks independently with retry logic
📊 **Detailed Tracking** - Complete execution history with logs for every step
🎯 **Priority Queuing** - High-priority tasks processed first
🏗️ **Microservices-Ready** - Modular architecture designed for Docker/Kubernetes migration
🔌 **Portable Abstractions** - Easy swap from database queue → Redis, local storage → S3
📡 **RESTful API** - Clean, well-documented endpoints with OpenAPI/Swagger
🛡️ **Enterprise Patterns** - Repository pattern, dependency injection, service layer architecture

## Quick Start

### Prerequisites

- Replit account (or Python 3.11+ locally)
- OpenAI API key ([Get one here](https://platform.openai.com/api-keys))
- PostgreSQL database (automatically provided by Replit)

### 1. Set Up Environment

Add your OpenAI API key to Replit Secrets or create a `.env` file:

```bash
OPENAI_API_KEY=sk-your-api-key-here
```

### 2. Install Dependencies

Dependencies are automatically installed on Replit. For local development:

```bash
pip install -r requirements.txt
```

### 3. Run the Application

On Replit, the server starts automatically. For local:

```bash
python -m uvicorn app.main:app --host 0.0.0.0 --port 5000 --reload
```

### 4. Test the API

```bash
# Health check
curl https://your-replit-app.repl.co/api/v1/health

# Create a task
curl -X POST "https://your-replit-app.repl.co/api/v1/tasks" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Create Instagram marketing strategy",
    "description": "Design a 30-day Instagram content plan for a coffee shop"
  }'

# Check task status (replace with your task ID)
curl https://your-replit-app.repl.co/api/v1/tasks/YOUR-TASK-ID
```

## Architecture

```
┌─────────┐
│ Client  │
└────┬────┘
     │
┌────▼─────────────────────────────────┐
│     FastAPI Application (5000)       │
│  ┌───────────────────────────────┐  │
│  │  API Routes (controllers)     │  │
│  │  • POST /tasks                │  │
│  │  • GET /tasks/{id}            │  │
│  │  • GET /tasks/{id}/result     │  │
│  └────────────┬──────────────────┘  │
│               │                      │
│  ┌────────────▼──────────────────┐  │
│  │  Services (business logic)    │  │
│  │  • TaskService                │  │
│  │  • PlanningService (OpenAI)   │  │
│  └────────────┬──────────────────┘  │
│               │                      │
│  ┌────────────┼────────────┬─────┐ │
│  │            │            │     │ │
│  ▼            ▼            ▼     ▼ │
│ Repo      Queue      Storage  ... │
└────┬────────┬────────────┬─────────┘
     │        │            │
┌────▼────┐   │   ┌────────▼────────┐
│Database │◄──┘   │ Local Storage   │
│ • tasks │       │ (S3-ready)      │
│ • steps │       └─────────────────┘
│ • logs  │
│ • queue │
└────▲────┘
     │
┌────┴──────┐
│  Worker   │ (polls every 2s)
│ • Plan    │
│ • Execute │
└───────────┘
```

### Layers

1. **API Layer** - FastAPI routes, request/response handling
2. **Service Layer** - Business logic, LLM integration, orchestration
3. **Worker Layer** - Background async task processing
4. **Repository Layer** - Database CRUD operations
5. **Queue Layer** - Task queue abstraction (DB → Redis migration path)
6. **Storage Layer** - File storage abstraction (Local → S3 migration path)
7. **Core Layer** - Configuration, database, logging

## API Documentation

### Interactive Docs

- **Swagger UI:** `https://your-replit-app.repl.co/docs`
- **ReDoc:** `https://your-replit-app.repl.co/redoc`

### Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/v1/tasks` | Create a new task |
| `GET` | `/api/v1/tasks/{id}` | Get task status and logs |
| `GET` | `/api/v1/tasks/{id}/result` | Get task result (when completed) |
| `GET` | `/api/v1/tasks` | List all tasks (with filters) |
| `GET` | `/api/v1/health` | Health check |

### Example: Create a Task

```bash
curl -X POST "https://your-replit-app.repl.co/api/v1/tasks" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Generate blog content ideas",
    "description": "Create 20 blog post ideas for a fitness brand targeting millennials, with SEO keywords",
    "priority": 7,
    "metadata": {
      "industry": "fitness",
      "audience": "millennials"
    }
  }'
```

**Response:**
```json
{
  "id": "550e8400-e29b-41d4-a716-446655440000",
  "title": "Generate blog content ideas",
  "status": "pending",
  "priority": 7,
  "created_at": "2025-11-23T21:50:07.123456",
  "steps": []
}
```

See [TESTING.md](TESTING.md) for comprehensive API examples.

## How It Works

### 1. Task Creation
- Client submits a task via POST request
- System validates input and generates unique task ID
- Task added to priority queue
- Worker picks up task within 2 seconds

### 2. LLM Planning
- PlanningService sends task to OpenAI GPT-4o-mini
- LLM analyzes task and creates 3-10 execution steps
- Each step includes:
  - Step number and name
  - Detailed description
  - Estimated duration
  - Dependencies on other steps
- Steps saved to database

### 3. Execution
- Worker executes steps sequentially
- Each step: pending → executing → completed/failed
- Detailed logs created for each action
- Results stored in structured format
- Errors trigger automatic retry (up to 3 times)

### 4. Completion
- All steps completed successfully
- Aggregated result generated
- Client retrieves via `/tasks/{id}/result`

## Project Structure

```
/
├── app/
│   ├── api/              # FastAPI routes
│   ├── services/         # Business logic
│   ├── workers/          # Background workers
│   ├── models/           # SQLAlchemy models
│   ├── schemas/          # Pydantic schemas
│   ├── repositories/     # Data access layer
│   ├── queue/            # Queue abstraction
│   ├── storage/          # Storage abstraction
│   ├── core/             # Configuration
│   └── main.py           # App entry point
│
├── requirements.txt      # Dependencies
├── TESTING.md           # API testing guide
├── ARCHITECTURE.md      # Architecture docs
└── README.md            # This file
```

## Configuration

### Environment Variables

```bash
# Required
DATABASE_URL=postgresql://...  # Auto-provided by Replit
OPENAI_API_KEY=sk-...          # Your OpenAI key

# Optional
OPENAI_MODEL=gpt-4o-mini       # LLM model
WORKER_CONCURRENCY=3           # Number of workers
WORKER_POLL_INTERVAL=2         # Poll interval (seconds)
TASK_TIMEOUT=300               # Task timeout (seconds)
MAX_RETRIES=3                  # Max retry attempts
```

See `.env.example` for all options.

## Database Schema

### Tasks
- Main task record with status, priority, metadata
- Relationships: steps, logs, result

### TaskSteps
- Individual executable steps
- Generated by LLM planning
- Input/output data tracking

### ExecutionLogs
- Detailed execution logs
- INFO, WARNING, ERROR levels
- Step-level granularity

### TaskResults
- Final aggregated results
- File paths for generated assets
- Summary information

### QueueItems
- Priority queue implementation
- Status tracking
- Error handling

## Migration to Production

This codebase is **designed for easy migration** to Docker/Kubernetes/AWS:

### Step 1: Add Redis Queue

```python
# app/queue/redis_queue.py
class RedisQueue(QueueInterface):
    # Implementation...
```

Update config: `QUEUE_TYPE=redis`

### Step 2: Add S3 Storage

```python
# app/storage/s3_storage.py
class S3Storage(StorageInterface):
    # Implementation...
```

Update config: `STORAGE_TYPE=s3`

### Step 3: Docker Compose

```yaml
services:
  api:
    build: .
    command: uvicorn app.main:app --host 0.0.0.0 --port 8000
  
  worker:
    build: .
    command: python -m app.workers.task_worker
    deploy:
      replicas: 3
  
  db:
    image: postgres:16
  
  redis:
    image: redis:7-alpine
  
  minio:
    image: minio/minio
```

**No code changes required!** Architecture abstractions handle everything.

See [ARCHITECTURE.md](ARCHITECTURE.md) for complete migration guide.

## Performance

### Current Setup (Replit)
- Single worker
- Database-backed queue
- Suitable for: 100-1000 tasks/day

### Production Setup (Docker/AWS)
- 3-10 workers (horizontally scalable)
- Redis queue
- S3 storage
- Suitable for: 10,000+ tasks/day

### Optimization Tips
1. Scale workers independently
2. Use Redis for queue (higher throughput)
3. Enable connection pooling
4. Add result caching
5. Implement rate limiting

## Monitoring

### Current Logging
- Structured logs to stdout
- Log levels: INFO, WARNING, ERROR
- Request/response logging

### Production Monitoring (Future)
- **Metrics:** Prometheus + Grafana
- **Tracing:** OpenTelemetry
- **Alerts:** PagerDuty / Slack
- **Logs:** ELK Stack / Datadog

## Security

### Current
- Environment-based secrets
- SQL injection protection (SQLAlchemy)
- CORS configuration
- Input validation (Pydantic)

### Production Requirements
- [ ] JWT authentication
- [ ] API rate limiting
- [ ] HTTPS only
- [ ] Secrets management (Vault)
- [ ] Audit logging
- [ ] RBAC authorization

## Cost Estimation

### OpenAI API
- Planning: ~$0.003 per task
- Execution (if AI-generated): ~$0.006 per task
- **Total: ~$0.01 per task**

### Infrastructure
- **Replit:** $0-20/month
- **AWS (Production):** ~$90/month + compute

### Scaling
- 1,000 tasks/day: ~$10/day OpenAI + minimal infrastructure
- 10,000 tasks/day: ~$100/day OpenAI + scaled infrastructure

## Development

### Run Tests
```bash
pytest app/tests/
```

### Code Style
```bash
black app/
flake8 app/
mypy app/
```

### Database Migrations
```bash
# Using direct table creation (current)
python -c "from app.core.database import init_db; init_db()"

# Future: Alembic migrations
alembic revision --autogenerate -m "description"
alembic upgrade head
```

## Roadmap

### ✅ Phase 1: MVP (Complete)
- [x] FastAPI REST API
- [x] LLM-powered task planning
- [x] Background workers
- [x] Database-backed queue
- [x] Execution logging
- [x] Modular architecture

### 🚧 Phase 2: Enhanced Features
- [ ] Redis/RabbitMQ queue
- [ ] S3/MinIO storage
- [ ] JWT authentication
- [ ] WebSocket real-time updates
- [ ] Task cancellation
- [ ] Result caching

### 📋 Phase 3: Enterprise
- [ ] Multi-tenancy
- [ ] RBAC authorization
- [ ] Billing integration (Stripe)
- [ ] Usage quotas
- [ ] Workflow templates
- [ ] Task scheduling (cron)

### 🤖 Phase 4: Advanced AI
- [ ] Multi-LLM support (Claude, Gemini)
- [ ] Agent-based execution
- [ ] Human-in-the-loop
- [ ] Quality scoring
- [ ] A/B testing

## Contributing

Contributions welcome! Please:

1. Fork the repository
2. Create a feature branch
3. Follow the layered architecture
4. Add tests for new features
5. Update documentation
6. Submit a pull request

## Support

- **Documentation:** See [TESTING.md](TESTING.md) and [ARCHITECTURE.md](ARCHITECTURE.md)
- **Issues:** Open an issue on GitHub
- **Questions:** Use GitHub Discussions

## License

MIT License - see LICENSE file for details

## Acknowledgments

- Built with [FastAPI](https://fastapi.tiangolo.com/)
- Powered by [OpenAI](https://openai.com/)
- Database by [PostgreSQL](https://www.postgresql.org/)
- Hosted on [Replit](https://replit.com/)

---

**Built with ❤️ for enterprise AI automation**
