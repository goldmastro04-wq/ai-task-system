# Production Readiness Checklist

## Current State: ✅ MVP Working on Replit

The AI Execution Hub is **functional for testing and demonstration** on Replit. The server is running, API endpoints work, and the basic task flow is operational.

**However**, the architect review identified critical issues that **must be fixed** before production deployment.

---

## Critical Issues Requiring Fixes

### 1. ⚠️ OpenAI Client Initialization

**Issue:**
- `PlanningService` instantiates OpenAI client in `__init__` without validation
- If `OPENAI_API_KEY` is missing or invalid, the **entire application crashes**
- No retry/backoff mechanism for API failures

**Impact:** HIGH - App won't start without valid API key

**Fix Required:**
```python
# app/services/planning_service.py
class PlanningService:
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or settings.OPENAI_API_KEY
        self.client = None
        
        if self.api_key and self.api_key.startswith('sk-'):
            try:
                self.client = OpenAI(api_key=self.api_key)
            except Exception as e:
                logger.warning(f"OpenAI client initialization failed: {e}")
        else:
            logger.warning("No valid OpenAI API key - using fallback planning only")
    
    async def create_execution_plan(self, ...):
        if not self.client:
            logger.info("No OpenAI client - using fallback plan")
            return self._create_fallback_plan(task_title, task_description)
        
        # Add retry logic with exponential backoff
        for attempt in range(3):
            try:
                response = self.client.chat.completions.create(...)
                return steps
            except Exception as e:
                if attempt < 2:
                    await asyncio.sleep(2 ** attempt)
                    continue
                logger.error(f"All retries failed: {e}")
                return self._create_fallback_plan(...)
```

---

### 2. ⚠️ Database Queue Race Conditions

**Issue:**
- `dequeue()` uses `first()` then updates status - **not atomic**
- Multiple workers can pick the same task
- Tasks can get stuck in "processing" state
- `mark_failed()` resets to "pending" without retry count - **infinite loop risk**

**Impact:** HIGH - Data corruption, infinite retries, task loss

**Fix Required:**
```python
# app/queue/database_queue.py
from sqlalchemy import select, update
from sqlalchemy.sql import func

class QueueItem(Base):
    __tablename__ = "queue_items"
    # ... existing fields ...
    retry_count = Column(Integer, default=0)
    max_retries = Column(Integer, default=3)
    locked_until = Column(DateTime, nullable=True)

async def dequeue(self, queue_name: str) -> Optional[Dict[str, Any]]:
    # Use SELECT FOR UPDATE SKIP LOCKED for atomic dequeue
    from sqlalchemy import text
    
    query = text("""
        UPDATE queue_items
        SET status = 'processing', 
            processed_at = NOW()
        WHERE id = (
            SELECT id FROM queue_items
            WHERE queue_name = :queue_name
              AND status = 'pending'
              AND (locked_until IS NULL OR locked_until < NOW())
            ORDER BY priority DESC, created_at
            LIMIT 1
            FOR UPDATE SKIP LOCKED
        )
        RETURNING id, task_id, task_data, priority
    """)
    
    result = self.db.execute(
        query,
        {"queue_name": queue_name}
    )
    self.db.commit()
    
    row = result.fetchone()
    if row:
        return dict(row)._mapping.get('task_data')
    return None

def mark_failed(self, task_id: str, error: str):
    """Mark queue item as failed with retry logic"""
    queue_item = self.db.query(QueueItem).filter(
        QueueItem.task_id == task_id,
        QueueItem.status == "processing"
    ).first()
    
    if queue_item:
        queue_item.retry_count += 1
        queue_item.error = error
        
        if queue_item.retry_count >= queue_item.max_retries:
            queue_item.status = "failed"
            logger.error(f"Task {task_id} exceeded max retries")
        else:
            queue_item.status = "pending"
            # Exponential backoff
            queue_item.locked_until = datetime.utcnow() + timedelta(
                seconds=2 ** queue_item.retry_count
            )
            logger.info(f"Task {task_id} retry {queue_item.retry_count}/{queue_item.max_retries}")
        
        self.db.commit()
```

---

### 3. ⚠️ Background Worker Concurrency Issues

**Issue:**
- Worker runs infinite loop with single blocking database session
- No graceful shutdown handling
- Settings say `WORKER_CONCURRENCY=3` but only 1 worker runs
- No error recovery or circuit breakers

**Impact:** MEDIUM - Can't scale, crashes block entire system

**Fix Required:**
```python
# app/workers/task_worker.py
import signal
import asyncio
from contextlib import contextmanager

class TaskWorker:
    def __init__(self):
        self.running = False
        self.poll_interval = settings.WORKER_POLL_INTERVAL
        self.shutdown_event = asyncio.Event()
    
    async def start(self):
        """Start the worker loop with graceful shutdown"""
        self.running = True
        logger.info("Task worker started")
        
        # Handle shutdown signals
        loop = asyncio.get_event_loop()
        for sig in (signal.SIGTERM, signal.SIGINT):
            loop.add_signal_handler(
                sig, 
                lambda: asyncio.create_task(self.stop())
            )
        
        while self.running:
            try:
                await self._process_next_task()
            except Exception as e:
                logger.error(f"Worker error: {e}", exc_info=True)
            
            # Check for shutdown signal
            try:
                await asyncio.wait_for(
                    self.shutdown_event.wait(),
                    timeout=self.poll_interval
                )
                break
            except asyncio.TimeoutError:
                continue
    
    async def _process_next_task(self):
        """Process the next task with fresh session per task"""
        db: Session = SessionLocal()  # Fresh session each time
        
        try:
            queue = DatabaseQueue(db)
            task_data = await queue.dequeue("task_queue")
            
            if not task_data:
                return
            
            task_id = task_data.get("task_id")
            
            # Process with timeout
            try:
                async with asyncio.timeout(settings.TASK_TIMEOUT):
                    task_service = TaskService(db)
                    success = await task_service.plan_task(task_id)
                    if success:
                        success = await task_service.execute_task(task_id)
                
                if success:
                    queue.mark_completed(task_id)
                else:
                    queue.mark_failed(task_id, "Task execution failed")
                    
            except asyncio.TimeoutError:
                logger.error(f"Task {task_id} timed out")
                queue.mark_failed(task_id, f"Timeout after {settings.TASK_TIMEOUT}s")
            except Exception as e:
                logger.error(f"Task {task_id} failed: {e}")
                queue.mark_failed(task_id, str(e))
        
        finally:
            db.close()
```

---

### 4. ⚠️ TaskService Transaction Management

**Issue:**
- Calling `repository.update_task(step.task)` commits entire session mid-execution
- If step 3 fails, steps 1-2 are already committed (partial state)
- No rollback mechanism
- No retry logic despite `MAX_RETRIES` setting

**Impact:** HIGH - Data inconsistency, stuck tasks

**Fix Required:**
```python
# app/services/task_service.py
async def execute_task(self, task_id: str) -> bool:
    """Execute all steps of a task with proper transaction handling"""
    
    task = self.repository.get_task_with_details(task_id)
    if not task:
        return False
    
    self._create_log(task_id, "INFO", "Starting task execution")
    
    try:
        results = []
        
        for step in sorted(task.steps, key=lambda s: s.step_number):
            # Execute step with retries
            for attempt in range(settings.MAX_RETRIES):
                try:
                    step_result = await self._execute_step(task_id, step)
                    results.append(step_result)
                    
                    if step_result.get("success", False):
                        break  # Step succeeded
                    else:
                        if attempt < settings.MAX_RETRIES - 1:
                            logger.info(f"Step {step.step_number} failed, retrying ({attempt + 1}/{settings.MAX_RETRIES})")
                            await asyncio.sleep(2 ** attempt)  # Exponential backoff
                        else:
                            raise Exception(f"Step {step.step_number} failed after {settings.MAX_RETRIES} attempts")
                
                except Exception as e:
                    if attempt < settings.MAX_RETRIES - 1:
                        continue
                    raise
        
        # All steps completed - now commit the result
        task_result = TaskResult(
            task_id=task_id,
            result_data={"steps_completed": len(results), "step_results": results},
            summary=f"Successfully completed {len(results)} steps"
        )
        self.repository.create_result(task_result)
        
        task.status = TaskStatus.COMPLETED
        task.completed_at = datetime.utcnow()
        self.repository.update_task(task)
        
        self._create_log(task_id, "INFO", "Task completed successfully")
        return True
        
    except Exception as e:
        logger.error(f"Error executing task {task_id}: {e}")
        
        # Rollback - mark task as failed
        task.status = TaskStatus.FAILED
        task.error_message = str(e)
        task.retry_count += 1
        self.repository.update_task(task)
        
        self._create_log(task_id, "ERROR", f"Execution failed: {str(e)}")
        return False

async def _execute_step(self, task_id: str, step: TaskStep) -> Dict[str, Any]:
    """Execute a single step - updates committed immediately"""
    
    step.status = StepStatus.EXECUTING
    step.started_at = datetime.utcnow()
    self.db.commit()  # Commit step status change
    
    try:
        output = {
            "step_number": step.step_number,
            "step_name": step.name,
            "result": f"Mock execution result for: {step.description}",
            "success": True
        }
        
        step.output_data = output
        step.status = StepStatus.COMPLETED
        step.completed_at = datetime.utcnow()
        self.db.commit()  # Commit step completion
        
        return output
        
    except Exception as e:
        step.status = StepStatus.FAILED
        step.error_message = str(e)
        self.db.commit()  # Commit step failure
        raise
```

---

### 5. ⚠️ API Error Handling

**Issue:**
- No structured exception handling
- Database errors return 500 with stack traces
- No request ID tracking
- CORS wide open (`allow_origins=["*"]`)

**Impact:** MEDIUM - Security risk, poor debugging

**Fix Required:**
```python
# app/core/exceptions.py (new file)
from fastapi import HTTPException, Request, status
from fastapi.responses import JSONResponse

class TaskNotFoundException(Exception):
    pass

class TaskNotCompletedException(Exception):
    pass

async def custom_exception_handler(request: Request, exc: Exception):
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "error": "Internal server error",
            "message": "An unexpected error occurred",
            "request_id": request.state.request_id if hasattr(request.state, 'request_id') else None
        }
    )

# app/main.py
from app.core.exceptions import custom_exception_handler

app.add_exception_handler(Exception, custom_exception_handler)

# Update CORS for production
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS.split(","),  # From env var
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE"],
    allow_headers=["*"],
)
```

---

## Additional Production Requirements

### Authentication & Authorization
- [ ] Implement JWT token authentication
- [ ] Add API key support for machine-to-machine
- [ ] Role-based access control (RBAC)
- [ ] Rate limiting per user/API key

### Monitoring & Observability
- [ ] Add Prometheus metrics (task duration, queue length, errors)
- [ ] Implement distributed tracing (OpenTelemetry)
- [ ] Set up alerting (PagerDuty, Slack)
- [ ] Log aggregation (ELK, Datadog)

### Infrastructure
- [ ] Replace database queue with Redis
- [ ] Replace local storage with S3
- [ ] Add health check endpoints for load balancer
- [ ] Implement circuit breakers for external APIs
- [ ] Database connection pooling tuning

### Testing
- [ ] Unit tests for all services
- [ ] Integration tests for API endpoints
- [ ] Load testing (Locust, k6)
- [ ] Chaos engineering tests

---

## Migration Priority

### Phase 1: Critical Fixes (Required Before Production)
1. Fix OpenAI client initialization with validation
2. Fix database queue race conditions
3. Fix worker transaction management
4. Add structured error handling

### Phase 2: Production Infrastructure
1. Migrate to Redis queue
2. Migrate to S3 storage
3. Add authentication
4. Add monitoring

### Phase 3: Scaling & Optimization
1. Horizontal worker scaling
2. Result caching
3. Performance tuning
4. Advanced retry strategies

---

## Testing the Current MVP

**The current system works for testing** with these caveats:

1. **Set OPENAI_API_KEY** or expect fallback plans only
2. **Run single worker only** (don't scale yet)
3. **Don't stress test** (queue has race conditions)
4. **Monitor logs** for stuck tasks

### Test Commands:

```bash
# 1. Health check
curl https://your-app.repl.co/api/v1/health

# 2. Create test task
curl -X POST "https://your-app.repl.co/api/v1/tasks" \
  -H "Content-Type: application/json" \
  -d '{"title": "Test Task", "description": "Simple test"}'

# 3. Check status (wait 5-10 seconds)
curl https://your-app.repl.co/api/v1/tasks/TASK_ID

# 4. Get result
curl https://your-app.repl.co/api/v1/tasks/TASK_ID/result
```

---

## Summary

**Current State:**
- ✅ MVP is functional for demonstration
- ✅ Architecture is well-designed and modular
- ✅ Code is clean and follows patterns
- ⚠️ Has critical bugs that prevent production use
- ⚠️ Needs transaction fixes and error handling

**Recommendation:**
1. **For Replit testing:** Use as-is with caution
2. **For production:** Implement all critical fixes first
3. **For scaling:** Migrate to Redis + S3 + multiple workers

The architecture is solid - the issues are implementation details that can be fixed systematically.
